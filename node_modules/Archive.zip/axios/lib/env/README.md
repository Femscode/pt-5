# axios // env

The `data.js` file is updated automatically when the package version is upgrading. Please do not edit it manually.

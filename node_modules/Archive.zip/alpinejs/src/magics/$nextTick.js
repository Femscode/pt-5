import { nextTick } from '../nextTick'
import { magic } from '../magics'

magic('nextTick', () => nextTick)
